{
	//This function disables the Foes Filed achievement
Game_Party.prototype.addDefeatedEnemy = function(id) {
  // Of Defeated Enemies array does not contain ID
  if (!this._defeatedEnemies.contains(id)) {
    // Add ID to defeated enemies array
    this._defeatedEnemies.push(id);
  };
  let allEnemies = Object.keys(LanguageManager.getTextData('Bestiary', 'Information')).map(Number);
};

//These two functions change the page turning sound to a TV blip
Window_OmoBestiaryEnemyList.prototype.selectNextEnemy = function() {
  // Get Starting Index
  var index = (this.index() + 1)
  if(index >= this.maxItems()) {
    index = 0;
  }
  var selected = false;
  // Go Through Items
  for (var i = index; i < this.maxItems(); i++) {
    // If item has a valid ID
    if (this._list[i].ext !== 0) {
      // audio
      AudioManager.playSe({name: "SE_TV_BLIP", pan: 0, pitch: 100, volume: 90});
      // Select it
      this.select(i);
      selected = true;
      break;
    };
  };
  if(!!selected) {return;}
};

Window_OmoBestiaryEnemyList.prototype.selectPreviousEnemy = function() {
  // Get Starting Index
  var index = (this.index() - 1) < 0 ? this.maxItems() - 1 : this.index() - 1;
  // Go Through Items
  for (var i = index; i >= 0; i--) {
    // If item has a valid Id
    if (this._list[i].ext !== 0) {
      // audio
      AudioManager.playSe({name: "SE_TV_BLIP", pan: 0, pitch: 100, volume: 90});
      // Select it
      this.select(i);
      break;
    };
  };
};

/*==============================================

FIX NAME INPUT MESSAGE LOL

==============================================*/
Window_OmoriNameInputName.prototype.refresh = function() {
  // Clear Contents
  this.contents.clear();
  this.contents.fontSize = 23
  this.contents.drawText('请输入密码', 0, 1, this.contents.width, this.contents.fontSize, 'center');
  this.contents.fillRect(0, 32, this.contents.width, 2, 'rgba(255, 255, 255, 1)');
  // Refresh Text
  this.refreshText();
};

/*===============================================

Stopping BGS from being cut by battle Starting

================================================*/
Scene_Map.prototype.stopAudioOnBattleStart = function() {
    if (!AudioManager.isCurrentBgm($gameSystem.battleBgm())) {
        AudioManager.stopBgm();
    }
    //AudioManager.stopBgs();
    AudioManager.stopMe();
    AudioManager.stopSe();
};

BattleManager.playBattleBgm = function() {
    AudioManager.playBgm($gameSystem.battleBgm());
    //AudioManager.stopBgs();
};

}
