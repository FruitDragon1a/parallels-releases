// ScrollingTextFix.js Ver.1.1.0
// MIT License (C) 2023 あわやまたな
// http://opensource.org/licenses/mit-license.php

/*:
* @target MZ MV
* @plugindesc Fix Show Scrolling Text.
* @author あわやまたな (Awaya_Matana)
* @url https://awaya3ji.seesaa.net/
* @help Ver.1.1.0
* Solved the problem that when the number of lines increases,
* the bitmap size exceeds the upper limit and the screen turns black.
*
* @param bitmapHeight
* @text Bitmap Height
* @desc Maximum height of generated bitmaps.
* Basically no need to change.
* @type number
* @default 2048
*
*/

/*:ja
* @target MZ MV
* @plugindesc 文章のスクロールを修正します。
* @author あわやまたな (Awaya_Matana)
* @url https://awaya3ji.seesaa.net/
* @help 行数が多くなるとビットマップサイズの上限を突破して画面が真っ黒になる
* 不具合を解消します。
*
* [更新履歴]
* 2023/02/13：Ver.1.0.0　公開。
* 2023/02/20：Ver.1.1.0　負荷を軽減する処理を追加。
*
* @param bitmapHeight
* @text ビットマップ高さ
* @desc 生成するビットマップ高さの最大値です。
* 基本的に変更する必要はありません。
* @type number
* @default 2048
*
*/

'use strict';

{
	const pluginName = document.currentScript.src.match(/^.*\/(.*).js$/);
	const parameters = PluginManager.parameters('ScrollingTextFix.js');
	const bitmapHeight = Number(parameters["bitmapHeight"]);

	//-----------------------------------------------------------------------------
	// Window_ScrollText

	const _Window_ScrollText_initialize = Window_ScrollText.prototype.initialize;
	Window_ScrollText.prototype.initialize = function(rect) {
		this._scrollY = 0;
		this._scrollBaseY = 0;
		_Window_ScrollText_initialize.call(this, rect);
	};

	//startMessageですでに変換後の文字列が入っているので二回目以降はスルー。
	const _Window_ScrollText_convertEscapeCharacters = Window_ScrollText.prototype.convertEscapeCharacters;
	Window_ScrollText.prototype.convertEscapeCharacters = function(text) {
		return this._text || Window_Base.prototype.convertEscapeCharacters.apply(this, arguments);
	};

	const _Window_ScrollText_startMessage = Window_ScrollText.prototype.startMessage;
	Window_ScrollText.prototype.startMessage = function() {
		//ここで事前に制御文字を変換しておくことでリフレッシュ時の負荷を減らす。
		$gameMessage._texts = [this.convertEscapeCharacters($gameMessage.allText())];
		this._scrollY = this._scrollBaseY = -this.height;//MV
		_Window_ScrollText_startMessage.call(this);
	};

	const _Window_ScrollText_updatePlacement = Window_ScrollText.prototype.updatePlacement;
	Window_ScrollText.prototype.updatePlacement = function() {
		_Window_ScrollText_updatePlacement.call(this);
		this._scrollY = this._scrollBaseY = -this.height;//MZ
	};

	const _Window_ScrollText_drawTextEx = Window_ScrollText.prototype.drawTextEx;
	Window_ScrollText.prototype.drawTextEx = function(text, x, y, width) {
		const blockHeight = this.scrollBlockHeight() || 1;
		this.origin.y = this._scrollY % blockHeight;
		y -= this._scrollY - this.origin.y;
		return _Window_ScrollText_drawTextEx.call(this, text, x, y, width);
	};

	const _Window_ScrollText_contentsHeight = Window_ScrollText.prototype.contentsHeight;
	Window_ScrollText.prototype.contentsHeight = function() {
		return Math.min(_Window_ScrollText_contentsHeight.call(this), bitmapHeight);
	};

	Window_ScrollText.prototype.updateMessage = function() {
		this._scrollY += this.scrollSpeed();
		this.updateOrigin();
		if (this._scrollY >= _Window_ScrollText_contentsHeight.call(this)) {
			this.terminateMessage();
		}
	};

	Window_ScrollText.prototype.scrollBlockHeight = function() {
		return bitmapHeight - this.height;
	};

	Window_ScrollText.prototype.updateOrigin = function() {
		const blockHeight = this.scrollBlockHeight() || 1;
		const baseY = this._scrollY - (this._scrollY % blockHeight);
		if (baseY !== this._scrollBaseY) {
			this.updateScrollBase(baseY);
			this.refresh();
		}
		this.origin.y = this._scrollY % blockHeight;
	};

	Window_ScrollText.prototype.updateScrollBase = function(baseY) {
		this._scrollBaseY = baseY;
	};
}