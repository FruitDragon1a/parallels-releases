//=============================================================================
// * Start
//=============================================================================
Scene_OmoriBestiary.prototype.start = function() {
  // Super Call
  Scene_BaseEX.prototype.start.call(this);
  // Start Fade in
  this.startFadeIn(this.slowFadeSpeed(), false);
  // Set page number
  pageNumber = 1;
};

//=============================================================================
// * Frame Update
//=============================================================================
Scene_OmoriBestiary.prototype.update = function() {
  // Super Call
  Scene_BaseEX.prototype.update.call(this);

  // If Enemy Text Window is visible
  if (this._enemyTextWindow.visible) {
    if (Input.isTriggered('cancel')) {
     pageNumber = 1;
      SoundManager.playCancel();
      this._enemyListWindow._onCursorChangeFunct = undefined;
      this._enemyListWindow.activate();
      this._enemyTextWindow.visible = false;
      this._enemyListWindow._onCursorChangeFunct = this.onListChangeUpdate.bind(this);
      return;
    }
    if (Input.isTriggered('left')) {
      pageNumber--
      if (pageNumber < 1) {
        pageNumber = 1;
        this._enemyListWindow.selectPreviousEnemy();
       this.onListChangeUpdate();
      } else {
          AudioManager.playSe({name: "SE_TV_BLIP", pan: 0, pitch: 100, volume: 90});
      }
      this.onEnemyListOk();
    };
    if (Input.isTriggered('right')) {
     pageNumber++
     if (pageNumber > 2) {
       pageNumber = 1;
        this._enemyListWindow.selectNextEnemy();
      this.onListChangeUpdate();
      } else {
          AudioManager.playSe({name: "SE_TV_BLIP", pan: 0, pitch: 100, volume: 90});
      }
      this.onEnemyListOk()
    };
  };
};

//=============================================================================
// * [OK] Enemy List
//=============================================================================
Scene_OmoriBestiary.prototype.onEnemyListOk = function() {
  // Get Enemy ID
  var enemyId =  this._enemyListWindow.enemyId();
  // Get Data
  var data = LanguageManager.getTextData('Bestiary', 'Information')[enemyId];
  // Make Enemy Text Window Visible
  this._enemyTextWindow.visible = true;

  // Get Lines
  var lines = data.pg1.text.replace(/\\/g, '\x1b');
    lines = lines.replace(/\x1b\x1b/g, '\\');
    lines = lines.replace(/\x1bV\[(\d+)\]/gi, function () {
        return $gameVariables.value(parseInt(arguments[1]));
    }.bind(this));
    lines = lines.replace(/\x1bV\[(\d+)\]/gi, function () {
        return $gameVariables.value(parseInt(arguments[1]));
    }.bind(this));
    lines = lines.replace(/\x1bEVALTEXT<<(.*?)>>/gi, function () {
        return eval(arguments[1]);
    }.bind(this));
   lines = lines.split(/[\r\n]/g);
   
  // Page 2 
  var lines2 = data.pg2.text.replace(/\\/g, '\x1b');
    lines2 = lines2.replace(/\x1b\x1b/g, '\\');
    lines2 = lines2.replace(/\x1bV\[(\d+)\]/gi, function () {
        return $gameVariables.value(parseInt(arguments[1]));
    }.bind(this));
    lines2 = lines2.replace(/\x1bV\[(\d+)\]/gi, function () {
        return $gameVariables.value(parseInt(arguments[1]));
    }.bind(this));
    lines2 = lines2.replace(/\x1bEVALTEXT<<(.*?)>>/gi, function () {
        return eval(arguments[1]);
    }.bind(this));
   lines2 = lines2.split(/[\r\n]/g);
   
   
  // Get Conditional Text
  var conditionalText = data.pg1.conditionalText;
  // If Conditional Text Exists
  if (conditionalText) {
    // Go through conditional text
    for (var i = 0; i < conditionalText.length; i++) {
      // Get text Data
      var textData = conditionalText[i];
      // Check if all switches are active
      if (textData.switchIds.every(function(id) { return $gameSwitches.value(id); })){
        // Get Line Index
        var lineIndex = textData.line === null ? lines.length : textData.line;
        // Get Extra Lines
        var extraLines = textData.pg1.text.split(/[\r\n]/g);
        // Add extra lines to main lines array
        lines.splice(lineIndex, 0, ...extraLines)
      };
    };
  }

  // Draw Lines
  switch (pageNumber) {
   case 1:
     this._enemyTextWindow.drawLines(lines, enemyId);
     break;
   case 2:
     this._enemyTextWindow.drawLines(lines2, enemyId);
     break;
   default:
   this._enemyTextWindow.drawLines(lines, enemyId);
  }
  // Get Character
  var character = this._enemyTextWindow._enemyCharacter;
  let sprite = this._enemyTextWindow._characterSprite;
  // If Character Data Exists
  if (data.character) {
    // Set Character Image
    character.setImage(data.character.name, data.character.index);
  } else {
    // Set Character Image to nothing
    character.setImage('', 0);
  };
  // Update Sprite
  sprite.update()
  // Update Character
  this._enemyTextWindow.updateCharacter();
  this._enemyTextWindow._characterSprite.update();
};

//=============================================================================
// * Draw Information
//=============================================================================
Window_OmoBestiaryEnemyText.prototype.drawLines = function(lines, enemyId) {
  // Clear Contents
  this.contents.clear();
  // Go Through Lines
  for (var i = 0; i < lines.length; i++) {
    // Draw Line
    if (lines.length >= 15 && lines.length < 20) {
    // Smaller line spacing to fit more text (15-19 lines)
    this.drawText(lines[i], 0, -14 + (i * 20), this.contents.width, 24);
    } else if (lines.length >= 20 && lines.length < 35){
    // Change the font size to fit more text (20-34)
    this.contents.fontSize = 12;
    this.drawText(lines[i], 0, -14 + (i * 12), this.contents.width, 24);
    } else if (lines.length >= 35){
    // Change the font size to fit more text (35+ lines)
    this.contents.fontSize = 10;
    this.drawText(lines[i], 0, -14 + (i * 10.5), this.contents.width, 24);
    } else { 
    this.drawText(lines[i], 0, -10 + (i * 28), this.contents.width, 24);
    }
    // Reset font size
    this.contents.fontSize = 15;
  };
  if (pageNumber == 2) {     // Make page 2 show the foe's stats     
     if (enemyId == 881) { // Show stats for all three breadkids
        this.drawText("HEART: ", 0, 14, this.contents.width, 24);
        this.drawText(`${$dataEnemies[113].params[0]}/${$dataEnemies[121].params[0]}/${$dataEnemies[117].params[0]}`, 120, 14, this.contents.width, 24);
        i = 1;
        this.drawText("JUICE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[113].params[1]}/${$dataEnemies[121].params[1]}/${$dataEnemies[117].params[1]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("ATTACK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[113].params[2]}/${$dataEnemies[121].params[2]}/${$dataEnemies[117].params[2]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("DEFENSE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[113].params[3]}/${$dataEnemies[121].params[3]}/${$dataEnemies[117].params[3]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("SPEED: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[113].params[6]}/${$dataEnemies[121].params[6]}/${$dataEnemies[117].params[6]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("LUCK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[113].params[7]}/${$dataEnemies[121].params[7]}/${$dataEnemies[117].params[7]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("HIT: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${($dataEnemies[113].traits[0].value * 100)}/${($dataEnemies[121].traits[0].value * 100)}/${($dataEnemies[117].traits[0].value * 100)}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("REWARDS - ", 0, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("CLAMS: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[113].gold}/${$dataEnemies[121].gold}/${$dataEnemies[117].gold}`, 120, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("EXPERIENCE: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[113].exp}/${$dataEnemies[121].exp}/${$dataEnemies[117].exp}`, 120, 28 + (i * 24), this.contents.width, 24);
    } else if (enemyId == 202 && $gameSwitches.value(1038)) { // Show stats for both gator guy versions
        this.drawText("HEART: ", 0, 14, this.contents.width, 24);
        this.drawText(`${$dataEnemies[202].params[0]}/${$dataEnemies[510].params[0]}`, 120, 14, this.contents.width, 24);
        i = 1;
        this.drawText("JUICE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[202].params[1]}/${$dataEnemies[510].params[1]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("ATTACK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[202].params[2]}/${$dataEnemies[510].params[2]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("DEFENSE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[202].params[3]}/${$dataEnemies[510].params[3]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("SPEED: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[202].params[6]}/${$dataEnemies[510].params[6]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("LUCK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[202].params[7]}/${$dataEnemies[510].params[7]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("HIT: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${($dataEnemies[202].traits[0].value * 100)}/${($dataEnemies[510].traits[0].value * 100)}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("REWARDS - ", 0, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("CLAMS: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[202].gold}/${$dataEnemies[510].gold}`, 120, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("EXPERIENCE: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[202].exp}/${$dataEnemies[510].exp}`, 120, 28 + (i * 24), this.contents.width, 24);
    } else if (enemyId == 880) { // Show stats for pluto and both arms
        this.drawText("HEART: ", 0, 14, this.contents.width, 24);
        this.drawText(`${$dataEnemies[357].params[0]}/${$dataEnemies[353].params[0]}/${$dataEnemies[361].params[0]}`, 120, 14, this.contents.width, 24);
        i = 1;
        this.drawText("JUICE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[357].params[1]}/${$dataEnemies[353].params[1]}/${$dataEnemies[361].params[1]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("ATTACK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[357].params[2]}/${$dataEnemies[353].params[2]}/${$dataEnemies[361].params[2]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("DEFENSE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[357].params[3]}/${$dataEnemies[353].params[3]}/${$dataEnemies[361].params[3]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("SPEED: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[357].params[6]}/${$dataEnemies[353].params[6]}/${$dataEnemies[361].params[6]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("LUCK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[357].params[7]}/${$dataEnemies[353].params[7]}/${$dataEnemies[361].params[7]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("HIT: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${($dataEnemies[357].traits[0].value * 100)}/${($dataEnemies[353].traits[0].value * 100)}/${($dataEnemies[361].traits[0].value * 100)}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("REWARDS - ", 0, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("CLAMS: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[357].gold}/${$dataEnemies[353].gold}/${$dataEnemies[361].gold}`, 120, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("EXPERIENCE: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[357].exp}/${$dataEnemies[353].exp}/${$dataEnemies[361].exp}`, 120, 28 + (i * 24), this.contents.width, 24);
    } else if (enemyId == 577) { // Show stats for all humphrey phases
        this.drawText("HEART: ", 0, 14, this.contents.width, 24);
        this.drawText(`${$dataEnemies[577].params[0]}/${$dataEnemies[581].params[0]}/${$dataEnemies[585].params[0]}/${$dataEnemies[589].params[0]}`, 120, 14, this.contents.width, 24);
        i = 1;
        this.drawText("JUICE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[577].params[1]}/${$dataEnemies[581].params[1]}/${$dataEnemies[585].params[1]}/${$dataEnemies[589].params[1]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("ATTACK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[577].params[2]}/${$dataEnemies[581].params[2]}/${$dataEnemies[585].params[2]}/${$dataEnemies[589].params[2]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("DEFENSE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[577].params[3]}/${$dataEnemies[581].params[3]}/${$dataEnemies[585].params[3]}/${$dataEnemies[589].params[3]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("SPEED: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[577].params[6]}/${$dataEnemies[581].params[6]}/${$dataEnemies[585].params[6]}/${$dataEnemies[589].params[6]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("LUCK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${$dataEnemies[577].params[7]}/${$dataEnemies[581].params[7]}/${$dataEnemies[585].params[7]}/${$dataEnemies[589].params[7]}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("HIT: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText(`${($dataEnemies[577].traits[0].value * 100)}/${($dataEnemies[581].traits[0].value * 100)}/${($dataEnemies[585].traits[0].value * 100)}/${($dataEnemies[589].traits[0].value * 100)}`, 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("REWARDS - ", 0, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("CLAMS: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText($dataEnemies[589].gold, 120, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("EXPERIENCE: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText($dataEnemies[589].exp, 120, 28 + (i * 24), this.contents.width, 24);
    } else if (enemyId == 146) { // Show stats for both rare bear stat sets
        this.drawText("HEART: ", 0, 14, this.contents.width, 24);
        this.drawText($dataEnemies[146].params[0], 120, 14, this.contents.width, 24);
        i = 1;
        this.drawText("JUICE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText($dataEnemies[146].params[1], 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("ATTACK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${$dataEnemies[146].params[2]}/\\c[8]${Math.round($dataEnemies[149].params[2] * $dataStates[14].traits[0].value)}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("DEFENSE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${$dataEnemies[146].params[3]}/\\c[8]${Math.round($dataEnemies[149].params[3] * $dataStates[14].traits[1].value)}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("SPEED: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${$dataEnemies[146].params[6]}/\\c[8]${$dataEnemies[149].params[6]}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("LUCK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${$dataEnemies[146].params[7]}/\\c[8]${$dataEnemies[149].params[7]}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("HIT: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${($dataEnemies[146].traits[0].value * 100)}/\\c[8]${($dataEnemies[149].traits[0].value * 100)}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("REWARDS - ", 0, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("CLAMS: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText($dataEnemies[146].gold, 120, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("EXPERIENCE: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText($dataEnemies[146].exp, 120, 28 + (i * 24), this.contents.width, 24);
    } else if (enemyId == 402) { // Show emotion stats for space ex husband
        this.drawText("HEART: ", 0, 14, this.contents.width, 24);
        this.drawText($dataEnemies[402].params[0], 120, 14, this.contents.width, 24);
        i = 1;
        this.drawText("JUICE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText($dataEnemies[402].params[1], 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("ATTACK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${$dataEnemies[402].params[2]}/\\c[4]${$dataEnemies[403].params[2]}\\c[0]/\\c[1]${$dataEnemies[404].params[2]}\\c[0]/\\c[8]${Math.round($dataEnemies[405].params[2] * $dataStates[14].traits[0].value)}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("DEFENSE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${$dataEnemies[402].params[3]}/\\c[4]${$dataEnemies[403].params[3]}\\c[0]/\\c[1]${Math.round($dataEnemies[404].params[3] * $dataStates[10].traits[0].value)}\\c[0]/\\c[8]${Math.round($dataEnemies[405].params[3] * $dataStates[14].traits[1].value)}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("SPEED: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${$dataEnemies[402].params[6]}/\\c[4]${Math.round($dataEnemies[403].params[6] * $dataStates[6].traits[2].value)}\\c[0]/\\c[1]${Math.round($dataEnemies[404].params[6] * $dataStates[10].traits[1].value)}\\c[0]/\\c[8]${$dataEnemies[405].params[6]}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("LUCK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${$dataEnemies[402].params[7]}/\\c[4]${Math.round($dataEnemies[403].params[7] * $dataStates[6].traits[1].value)}\\c[0]/\\c[1]${$dataEnemies[404].params[7]}\\c[0]/\\c[8]${$dataEnemies[405].params[7]}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("HIT: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawTextEx(`${($dataEnemies[402].traits[0].value * 100)}/\\c[4]${Math.round(($dataEnemies[403].traits[0].value * 100) + (($dataEnemies[403].traits[0].value * 100) * $dataStates[6].traits[0].value))}\\c[0]/\\c[1]${($dataEnemies[404].traits[0].value * 100)}\\c[0]/\\c[8]${($dataEnemies[405].traits[0].value * 100)}\\c[0]`, 120, 14 + (i * 24));
        i++
        this.drawText("REWARDS - ", 0, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("CLAMS: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText($dataEnemies[402].gold, 120, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("EXPERIENCE: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText($dataEnemies[402].exp, 120, 28 + (i * 24), this.contents.width, 24);
	} else {
        if (enemyId == 877 || enemyId == 878 || enemyId == 879) { enemyId = 568 } // Make the slime girls show the correct values
        this.drawText(" - HEART: ", 0, 14, this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCHeart) || $dataEnemies[enemyId].params[0]), 120, 14, this.contents.width, 24);
        i = 1;
        this.drawText(" - JUICE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCJuice) || $dataEnemies[enemyId].params[1]), 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText(" - ATTACK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCAttack) || $dataEnemies[enemyId].params[2]), 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText(" - DEFENSE: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCDefense) || $dataEnemies[enemyId].params[3]), 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText(" - SPEED: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCSpeed) || $dataEnemies[enemyId].params[6]), 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText(" - LUCK: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCLuck) || $dataEnemies[enemyId].params[7]), 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText(" - HIT: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCHit) || ($dataEnemies[enemyId].traits[0].value * 100)), 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText(" - EVA: ", 0, 14 + (i * 24), this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCEva) || ($dataEnemies[enemyId].traits[1].value * 100)), 120, 14 + (i * 24), this.contents.width, 24);
        i++
        this.drawText("REWARDS - ", 0, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText(" - CLAMS: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText(Number($dataEnemies[enemyId].meta.CCClams) || $dataEnemies[enemyId].meta.CCClams || $dataEnemies[enemyId].gold, 120, 28 + (i * 24), this.contents.width, 24);
        i++
        this.drawText(" - EXP: ", 0, 28 + (i * 24), this.contents.width, 24);
        this.drawText((Number($dataEnemies[enemyId].meta.CCExp) || $dataEnemies[enemyId].exp), 120, 28 + (i * 24), this.contents.width, 24);
    }
  }
};