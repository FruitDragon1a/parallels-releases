// ====================================================================
// TDS OMORI Title Screen
// Version: 2.0
// Updated and fixed by Fruitdragon for parallels
// =====================================================================

// Add to Imported List in RPGMaker 
var Imported = Imported || {} ; Imported.TDS_OmoriTitleScreen = true;
// Initialize Alias Object
var _TDS_ = _TDS_ || {} ; _TDS_.OmoriTitleScreen = _TDS_.OmoriTitleScreen || {};
//=============================================================================
 /*:
 * @plugindesc
 * Title screen for Omori
 *
 * @author FruitDragon 
 * @ updated by FruitDragon
 *
 */
//=============================================================================


_TDS_.OmoriTitleScreen.Scene_Boot_start = Scene_Boot.prototype.start;

Scene_Boot.prototype.start = function() {

    Scene_Base.prototype.start.call(this);
    SoundManager.preloadImportantSounds();

    // skips putting the title screen if it's an rpgmaker battle test
    if (DataManager.isBattleTest()) {

        DataManager.setupBattleTest();
        SceneManager.goto(Scene_Battle);
    
    }
    // skips putting the title screen if its an rpgmaker event test
    else if (DataManager.isEventTest()) {

        DataManager.setupEventTest();
        SceneManager.goto(Scene_Map);
    
    }

    // sets up title screen in any other cases
    else {

        this.checkPlayerLocation();
        DataManager.setupNewGame();
        SceneManager.goto(Scene_OmoriTitleScreen);
        Window_TitleCommand.initCommandPosition();

    }

    this.updateDocumentTitle();

};


//=============================================================================
// * Initializes the object Scene_OmoriTitleScreen
// (this is a function required in any object, basically sets it up)
//=============================================================================
Scene_OmoriTitleScreen.prototype.initialize = function() {

// Set Image reservation Id
this._imageReservationId = 'title';
// Super Call
Scene_BaseEX.prototype.initialize.call(this);
// Get Atlas Bitmap
this._atlasBitmap = ImageManager.loadAtlas('Omori_TitleScreen');

// World Type 0: Normal, 1: Dark space, 2: Red Space
// Reads data of title screen images
let tryFile = DataManager.readFromFile("File");
let tryTitleData = DataManager.readFromFile("TITLEDATA");

// gets current world type if one exists, otherwise sets it to 0
if (!!tryTitleData) {
    this._worldType = parseInt(tryTitleData);
}
else if (!!tryFile) {
    this._worldType = parseInt(tryFile);
}
if (typeof this._worldType === "undefined") {
    this._worldType = 0;
}
// where the possible world types are declared
// this is where new switches would be added 
/* current declarations:
*  0: default, 
    444: blackspace (parallels dw)
    445: redspace 
    446: whitespace
    447: faraway; good ending
    448: bad ending
    449: good ending
*/
if(![0,444,445,446,447,448,449].contains(this._worldType)) {this._worldType = 0;}
// Set Command Active Flag
this._commandActive = false;
// Options Active Flag
this._optionsActive = false;
// Set Command Index Flag
this._commandIndex = 0;
// Instant Intro Flag
this._instantIntro = false;
// Determine if can continue
this._canContinue = false;
// Check if Save files exist
for (var i = 1; i < 7; i++) {
    if (StorageManager.exists(i)) { 
        this._canContinue = true; 
        break; 
    }
};
    this._instantIntro = true;
};


//=============================================================================
// * Prepare Scene
//=============================================================================
Scene_OmoriTitleScreen.prototype.prepare = function(index, instant = true) {
    // Set Command Index
    this._commandIndex = index;
    // Set Instant Intro Flag
    this._instantIntro = instant;
};

//=============================================================================
// * Initialize Atlas Lists
//=============================================================================
Scene_OmoriTitleScreen.prototype.initAtlastLists = function() {

    // Super Call
    Scene_BaseEX.prototype.initAtlastLists.call(this);

    // Add Required Atlas
    this.addRequiredAtlas('Omori_TitleScreen');

    // Reserve Images
    ImageManager.reservePicture('Blackspace_polaroidBG_FA_day', 0, this._imageReservationId);
    ImageManager.reservePicture('PRL_DW_TITLE', 0, this._imageReservationId)

    // Load Input Icons
    ImageManager.loadInputIcons();

}

//=============================================================================
// * Create - calls all functions
//=============================================================================
Scene_OmoriTitleScreen.prototype.create = function() {
    
    // Super Call
    Scene_BaseEX.prototype.create.call(this);

    
    this.createFilters();
    // Create Background
    this.createBackground();
    //Create Parallax Title
    this.createParallaxTitle();
    // Create Omori Sprite
    this.createOmoriSprite();
    // Create Title Sprites
    this.createTitleSprites();
    // Create Title Commands
    this.createTitleCommands();
    // Create Command Hints
    this.createCommandHints();
    // Create Version Text
    this.createVersionText();
    // Create Options Windows
    this.createOptionWindowsContainer();
    this.createHelpWindow();
    this.createGeneralOptionsWindow();
    this.createAudioOptionsWindow();
    this.createControllerOptionsWindow();
    this.createSystemOptionsWindow();
    this.createExitPromptWindow();
    this.createOptionCategoriesWindow();

    // Update world bitmaps
    this.updateWorldBitmaps();
    this.playBgm();
    this.playBgs();
    // this._backgroundSprite.filters = [this._glitchFilter]
};

// ================================================
// Choose BGM Audio 
// =====================================================
Scene_OmoriTitleScreen.prototype.playBgm = function () {

    // Declares variable
    var name;
    var volume;
    
    // Looks at conditions where the title music might change and changes accordingly
    
    if (this._worldType === 444) {
    name = "prl_discussion";
    volume = 100;
    }
    
    // otherwise, sets the music to the default
    else {
    name = "prl_title";
    volume = 100;
    }
    
    // plays the bgm 
    AudioManager.playBgm({name: name, volume: volume, pitch: 100});
};

// ======================================================
// Choose Ambient BGS Audio
// ======================================================

Scene_OmoriTitleScreen.prototype.playBgs = function() {
    var name;
    var volume;
    
    
    // if the previous save is in Black Space 
    if (this._worldType === 444) {

        //no bgs 

    } 
    
    else {

        // there's no code in here because there's no default bgs
    
    }
    
    // returns the name and volume given
    
    // this returns if there is nothing inside the name variable; eg if there is no bgs.
    if(!name) {
        return;
    }
    
    // otherwise, this one plays the bgs given
    AudioManager.playBgs({name: name, volume: volume, pitch: 100});
}

//=============================================================================
// * Create Background
//=============================================================================
Scene_OmoriTitleScreen.prototype.createBackground = function() {
    // Create Background Sprite
    this._backgroundSprite = new TilingSprite();
    this._backgroundSprite.move(0, 0, Graphics.width, Graphics.height);
    this.addChild(this._backgroundSprite);
    
    // checks if the title belongs to aubrey dw
    if (this._worldType === 444) {

        var bitmap = new Bitmap(Graphics.width, Graphics.height);
        bitmap.fillAll('rgba(255, 216, 165, 1)');
        this._backgroundSprite.bitmap = bitmap;    

    }
    
    // default title
    else {

        this._backgroundSprite.bitmap = ImageManager.loadParallax('!polaroidBG_FA_day'); 
    
    }

};

//=============================================================================
// * Create Parallax Title
//=============================================================================
Scene_OmoriTitleScreen.prototype.createParallaxTitle = function() {
    // Create Parallax Title
    this._parallaxTitleSprite = new TilingSprite();
    this._parallaxTitleSprite.move(0, 0, Graphics.width, Graphics.height);
    this.addChild(this._parallaxTitleSprite);
    
    // aubrey dw title
    if (this._worldType === 444) {

            this._parallaxTitleSprite.bitmap = ImageManager.loadParallax('parallels_title');
            
    }
    else {
        
        // place for white space title/default title
        this._parallaxTitleSprite.bitmap = ImageManager.loadParallax('parallels_title');    
    
    }
};

//=============================================================================
// * Create OMORI SPrite
//=============================================================================
Scene_OmoriTitleScreen.prototype.createOmoriSprite = function() {
    // Create Omori Sprite

    //prologue faraway title screen
    if (this._worldType === 444) {

        

    }
    else {

        this._omoriSprite = new Sprite(ImageManager.loadPicture('OMO_WS'));

    }

    // if the omori sprite doesnt exist, it doesnt load it
    if (this._omoriSprite){

        this._omoriSprite.anchor.set(0.5, 1)
        this._omoriSprite.x = Graphics.width / 2;
        this._omoriSprite.y = Graphics.height;
        this._omoriSprite.opacity = 0;
        this._omoriSprite.setFrame(0, 0, 0, 0);
        this._omoriSprite.filters = [this._glitchFilter];

        this._omoriSprite.visible = this._worldType !== 4;
        this._omoriSprite.filterArea = new PIXI.Rectangle(0, 0, Graphics.width, Graphics.height + Math.floor(Graphics.height / 6));
        this.addChild(this._omoriSprite);

    }

};

//=============================================================================
// * Create Title Sprites
//=============================================================================
Scene_OmoriTitleScreen.prototype.createTitleSprites = function() {
    // Create Title Text Container Sprite
    this._titleTextContainerSprite = new Sprite()
    this._titleTextContainerSprite.x = 167;
    this._titleTextContainerSprite.y = 130;
    this._titleTextContainerSprite.opacity = 0
    this.addChild(this._titleTextContainerSprite);
    
    
    if (this._worldType === 444) {
        this._lightBulbLinesSprite = new Sprite(ImageManager.loadPicture('PRL_DW_TITLE'));
    } else {
        this._lightBulbLinesSprite = new Sprite(ImageManager.loadPicture('OMO_BULB_WS_LINES'));
    }
        
    this._lightBulbLinesSprite.x = -167;
    this._lightBulbLinesSprite.y = 30;
    this._lightBulbLinesSprite.opacity = 0;
    this._lightBulbLinesSprite.setFrame(0, 0, 640, 480)
    this._titleTextContainerSprite.addChild(this._lightBulbLinesSprite);

    
};

//=============================================================================
// * Initialize Frame Animations
//=============================================================================
Scene_OmoriTitleScreen.prototype.initFrameAnimations = function() {
    // Initialize Frame Animations
    if (this._omoriSprite){
        this._frameAnimations = [
            {sprite: this._omoriSprite, rect: new Rectangle(0, 0, 306, 350), frames: [0, 1, 2], frameIndex: 0, delayCount:  0, delay: 20, active: true},
            {sprite: this._lightBulbLinesSprite, rect: new Rectangle(0, 0, 640, 480), frames: [0, 1, 2], frameIndex: 0, delayCount:  0, delay: 20, active: true}
        ]
    } else {
        this._frameAnimations = [
            {sprite: this._lightBulbLinesSprite, rect: new Rectangle(0, 0, 640, 480), frames: [0, 1, 2], frameIndex: 0, delayCount:  0, delay: 20, active: true}
        ]
    }
    // Update Frame animations
    this.updateFrameAnimations();
};

//=============================================================================
// * Update Bitmaps
//=============================================================================
Scene_OmoriTitleScreen.prototype.updateWorldBitmaps = function(world = this._worldType, temp = false) {
    // Set Title Bitmap
    var omoriBitmap = 'OMO_WS';
    var linesBitmap = 'OMO_BULB_BS_LINES';
    // Set World
    switch (world) {
    case 0: // White space
        break;
    case 446: // White space
        break;
    case 444: // Black space
        linesBitmap = 'PRL_DW_TITLE'
        break;
    case 445: // Red space
        linesBitmap = 'OMO_BULB_BS_LINES'
    break;
    case 449:
    case 447: // Ending Good
        linesBitmap = 'OMO_BULB_BS_LINES'
        break;
    case 448: // Ending Bad
        linesBitmap = 'OMO_BULB_BS_LINES'
        break;
    };
    if (temp) {
    //    titleTextBitmap = 'OMO_TITLE_BS';
    //    lightbulbBitmap = 'OMO_BULB_BS';
    //    stringBitmap =  'OMO_STRING_BS';
    //    linesBitmap = 'OMO_BULB_BS_LINES'
    }

    if (this._omoriSprite) this._omoriSprite.bitmap = ImageManager.loadPicture(omoriBitmap)
    this._lightBulbLinesSprite.bitmap = ImageManager.loadPicture(linesBitmap);
    // Set Omori Sprite Width & Height
    if (this._omoriSprite) this._omoriSprite.width = 306;
    if (this._omoriSprite) this._omoriSprite.height = 350;
    // Let Lines Width & Height
    this._lightBulbLinesSprite.width = 640;
    this._lightBulbLinesSprite.height =  480;
    

};

//=============================================================================
// * Start
//=============================================================================
Scene_OmoriTitleScreen.prototype.start = function() {
    // Super Call
    Scene_BaseEX.prototype.start.call(this);
    // Initialize Frame Animations
    this.initFrameAnimations();
    // If Instant Intro Flag is true
    if (this._instantIntro) {
      this._titleTextContainerSprite.opacity = 255;
      this._titleTextContainerSprite.y = -30;
      if (this._omoriSprite) this._omoriSprite.opacity = 255;
      this._lightBulbLinesSprite.opacity = 255;
      for (var i = 0; i < this._titleCommands.length; i++) {
        var win = this._titleCommands[i];
        win.y = (Graphics.height - win.height) - 15;
        win.opacity = 255;
        win.contentsOpacity = 255;
      };
      // Activate Commands
      this._commandActive = true;
      // Activate Bulb Light animation
      if (this._omoriSprite) this._frameAnimations[1].active = true;
      else this._frameAnimations[0].active = true;
      // Activate Glitch
    //  this._glitchSettings.active = this._worldType === 3;
    this._glitchSettings.active = this._worldType === 445
      return;
    };
  
    this.queue(function() {
      // Set Duration
      var duration = 60;
      var obj = this._titleTextContainerSprite;
      var data = { obj: obj, properties: ['opacity'], from: {opacity: obj.opacity}, to: {opacity: 255}, durations: {opacity: duration}}
      data.easing = Object_Movement.linearTween;
      this.move.startMove(data);
      if (this._omoriSprite) this._frameAnimations[1].active = true;
      else this._frameAnimations[0].active = true;
    }.bind(this))
  
    // Wait
    this.queue('setWaitMode', 'movement');
    // Wait
    this.queue('wait', 15);
  
    this.queue(function() {
      
  
      // Set Duration
      var duration = 60;
      var obj = this._lightBulbLinesSprite;
      var data = { obj: obj, properties: ['opacity'], from: {opacity: obj.opacity}, to: {opacity: 255}, durations: {opacity: duration}}
      data.easing = Object_Movement.linearTween;
      this.move.startMove(data);
  
    }.bind(this))
  
    // Wait
    this.queue('setWaitMode', 'movement');
    // Wait
    this.queue('wait', 30);
  
    this.queue(function() {
      // Set Duration
      var duration = 60;
      var obj = this._titleTextContainerSprite;
      var data = { obj: obj, properties: ['y'], from: {y: obj.y}, to: {y: -30}, durations: {y: duration}}
      data.easing = Object_Movement.linearTween;
      this.move.startMove(data);
    }.bind(this))
  
    // Wait
    this.queue('setWaitMode', 'movement');
    // Wait
    this.queue('wait', 30);
      if (this._omoriSprite) {
          this.queue(function() {
              // Set Duration
              var duration = 60;
              var obj = this._omoriSprite;
              var data = { obj: obj, properties: ['opacity'], from: {opacity: obj.opacity}, to: {opacity: 255}, durations: {opacity: duration}}
              data.easing = Object_Movement.linearTween;
              this.move.startMove(data);
          }.bind(this))
  
          // Wait
          this.queue('wait', 30);
      }
  
  
    for (var i = 0; i < this._titleCommands.length; i++) {
      // console.log(i)
      this.queue(function(index) {
        // Set Duration
        var duration = 30;
        var obj = this._titleCommands[index];
        obj.select(-1)
        var data = { obj: obj, properties: ['y', 'opacity', 'contentsOpacity'], from: {y: obj.y, opacity: obj.opacity, contentsOpacity: obj.contentsOpacity}, to: {y: (Graphics.height - obj.height) - 22, opacity: 255, contentsOpacity: 255}, durations: {y: duration, opacity: duration, contentsOpacity: duration}}
        data.easing = Object_Movement.easeOutCirc;
        this.move.startMove(data);
      }.bind(this, i))
      // Wait
      this.queue('wait', 15);
    };
  
    // console.log(i)
    this.queue(function() {
      // Activate Glitch
      this._glitchSettings.active =  this._worldType === 445
      // Activate Commands
      this._commandActive = true;
      // Update Command Window Selection
      this.updateCommandWindowSelection();
    }.bind(this, i))
  
  };
