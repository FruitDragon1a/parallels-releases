//=============================================================================
// Stahl Plugin - State Tiering
// Stahl_StateTiering.js    VERSION 1.0.3
//=============================================================================

var Imported = Imported || {};
Imported.Stahl_StateTiering = true;

var Stahl = Stahl || {};
Stahl.StateTiering = Stahl.StateTiering || {};

//=============================================================================
 /*:
 * @plugindesc v1.0.3 Gives handy functions related to emotions and buffs
 * @author ReynStahl
 * 
 * @help
 * When using parse text, there will be a delay to display text, so ideally put it after emotion
 * so there is no delay before it executes the functions, like animations.
 * 
 * ================ NOTES ================
 * "type" here refers to entire category of states. For example HAPPY type would mean HAPPY, ECSTATIC, and MANIC.
 * HAPPY being HAPPY tier 1, ECSTATIC being HAPPY tier 2, and MANIC being HAPPY tier 3.
 * 
 * 
 * ================ STATE NOTES (EMOTION) ================
 * <EMOTION TYPE: type, tier>
 * Specify what type of emotion, and what tier it is. Both parameter required.
 * Ex 1: HAPPY state; <EMOTION TYPE: HAPPY, 1>
 * Ex 2: ECSTATIC state; <EMOTION TYPE: HAPPY, 2>
 * 
 * <EMOTION STRONG: type>
 * Specify what type of emotion this emotion is strong against. Can be added multiple times.
 * Ex: HAPPY is strong against ANGRY; in HAPPY state input <EMOTION STRONG: ANGRY>
 * 
 * <EMOTION WEAK: type>
 * Specify what type of emotion this emotion is weak against. Can be added multiple times.
 * Ex: HAPPY is weak against SAD; in HAPPY state input <EMOTION WEAK: SAD>
 * 
 * <EMOTION STRONG ALL>
 * Specify emotion as strong to all emotions, including itself.
 * Ex: No example in base game
 * 
 * <EMOTION WEAK ALL>
 * Specify emotion as weak to all emotions, including itself.
 * Ex: AFRAID emotion is weak to all other emotion.
 * 
 * <EMOTION EXCLUDE FROM RANDOM>
 * Excludes emotion from addRandomEmotion() functions and it's variants.
 * Ex: Excluding AFRAID as it contains more special use case.
 * 
 * <EMOTION NO EFFECT TEXT: text>
 * This specifies the word (x) used for "target can't get x!". Similar to parseNoEffectEmotion() function.
 * If not specified, it will default to "target cannot be more stateName!"
 * Ex: HAPPY state; "target can't get HAPPIER!"; <EMOTION NO EFFECT TEXT: HAPPIER>
 * Ex: AFRAID state; "target cannot be more AFRAID!"; No note tag.
 * 
 * <EMOTION SUPPLEMENTARY BUFF: type>
 * <EMOTION SUP BUFF: type>
 * List of buff for buff that supports the emotion's strength. 
 * Used in more advanced add state functions. Can be added multiple times.
 * Ex: ANGRY supports ATTACK buff; <EMOTION SUPPLEMENTARY BUFF: ATTACK>
 * 
 * <EMOTION COMPLEMENTARY BUFF: type>
 * <EMOTION COM BUFF: type>
 * List of buff for buff that supports the emotion's weakness. 
 * Used in more advanced add state functions. Can be added multiple times.
 * Ex: ANGRY wants DEFENSE buff to cover; <EMOTION SUPPLEMENTARY BUFF: DEFENSE>
 * 
 * <EMOTION COPY TRAIT: stateId, tag>
 * Copies all the emotion traits of the stateId, and assign a unique tag (if provided)
 * Ex: SPACE EX ANGRY (state 119), is ANGRY state (state 14) but for SPACE EX-BOYFRIEND; <EMOTION COPY TRAIT: 14, SBF> (assuming SBF as tag)
 * Ex: SPACE EX ENRAGED (state 120), is ANGRY state (state 15) but for SPACE EX-BOYFRIEND; <EMOTION COPY TRAIT: 15, SBF> (assuming SBF as tag)
 * 
 * ================ STATE NOTES (STATEBUFF) ================
 * <STATE BUFF TYPE: type, +tier>
 * <STATE BUFF TYPE: type, -tier>
 * Specify what type of buff, and what tier it is. Both parameter required.
 * Ex 1: ATTACK UP 1 state; <EMOTION TYPE: ATTACK, +1>
 * Ex 2: DEFENSE UP 2 state; <EMOTION TYPE: DEFENSE, +2>
 * Ex 3: SPEED DOWN 3 state; <EMOTION TYPE: SPEED, -3>
 * 
 * NOTE: THIS IS ALSO USED AS MAIN NAME WHEN DISPLAYED IN PARSE TEXT AND REFERRING OTHER BUFF IN NOTES
 * 
 * <STATE BUFF ALT NAME: text>
 * These are alternate acceptable names when inputted into adding state type functions. 
 * For compatibility purposes. Can be added multiple times.
 * 
 * ================ ACTOR / ENEMIES / STATE NOTES ================
 * <EMOTION IMMUNE: type>
 * This is to specify when the battler is immune to an emotion. 
 * Used in parseEmotion text to display "target cannot feel x".
 * Ex: OMORI is immune to afraid; to display "OMORI cannot feel AFRAID"; <EMOTION IMMUNE: AFRAID>
 * 
 * <EMOTION IMMUNE ALL>
 * Same as EMOTION IMMUNE but with all emotion applied
 * Ex: SOMETHING enemies cannot be inflicted emotions
 * 
 * <EMOTION SUSCEPTIBILITY: int>
 * <EMOTION SUSCEPT: int>
 * Changes the tiering when used through addStateTier and it's variant.
 * Ex: Actor has emotionSuscept of 1; when given SAD (tier 1) => gets DEPRESSED (tier 2)
 * 
 * ================ ACTOR / ENEMIES NOTES ================
 * <EMOTION USE TAG: text>
 * Uses a set of emotion with a tag instead of the main ones. Used for boss states.
 * Ex: SPACE EX-BOYFRIEND have unique set of ANGRY states; <EMOTION USE TAG: SBF> (assuming SBF as tag)
 * 
 * @param ---General---
 * @default
 * 
 * @param CombineBuffs
 * @text Combine Buffs and Debuffs
 * @parent ---General---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Combine buff and debuffs, not to be separate added states. [NO IS EXPERIMENTAL]
 * NO - false     YES - true
 * @default true
 * 
 * @param ReaddState
 * @text Readd Maxed States
 * @parent ---General---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Readd the state even when it is the maximum. [Text may not properly tell the limit]
 * NO - false     YES - true
 * @default false
 * 
 * @param BuffAdjective
 * @text Buff Adjective
 * @parent ---General---
 * @type struct<BuffAdjectiveStructure>[]
 * @desc Text adjective to display when parsing different amount of buffs tier change. (i.e. PLAYER's STAT rose ADJECTIVE)
 * @default ["{\"tierChange\":\"1\",\"adjective\":\"\"}","{\"tierChange\":\"2\",\"adjective\":\"moderately!\"}","{\"tierChange\":\"3\",\"adjective\":\"greatly!\"}","{\"tierChange\":\"4\",\"adjective\":\"sharply!\"}","{\"tierChange\":\"5\",\"adjective\":\"significantly!\"}","{\"tierChange\":\"6\",\"adjective\":\"exceedingly!\"}"]
 * 
 * @param UseMaximumBuffText
 * @text Use Maximum Buff Text
 * @parent ---General---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Gives different text displaying "maximized/minimized" when giving large tier change buff.
 * NO - false     YES - true
 * @default true
 */
/*~struct~BuffAdjectiveStructure:
 *
 * @param tierChange
 * @text Tier Change
 * @type number
 * @desc Amount of tier changed associated with adjective.
 * @default 1
 * 
 * @param adjective
 * @text Adjective
 * @type text
 * @desc Adjective to be added.
 * @default adjectively!
 */
//=============================================================================

//=============================================================================
// Parameter Variables
//=============================================================================

Stahl.Parameters = PluginManager.parameters('Stahl_StateTiering');
Stahl.Param = Stahl.Param || {};
Stahl.Parsed = Stahl.Parsed || {};

Stahl.Param.CombineBuffs = eval(Stahl.Parameters['CombineBuffs']);
Stahl.Param.ReaddState = eval(Stahl.Parameters['ReaddState']);
Stahl.Param.BuffAdjective = JSON.parse(Stahl.Parameters['BuffAdjective']);
Stahl.Param.UseMaximumBuffText = eval(Stahl.Parameters['UseMaximumBuffText']);

Stahl.Parsed.BuffAdjective = PluginManager.parseObject(Stahl.Param.BuffAdjective);

//=============================================================================

var $dataEmotions = null;
var $dataStateBuffs = null;

// ================================ DATA MANAGER ================================ //
{
	Stahl.StateTiering.DataManager_isDatabaseLoaded = DataManager.isDatabaseLoaded;
	DataManager.isDatabaseLoaded = function() {
	if (!Stahl.StateTiering.DataManager_isDatabaseLoaded.call(this)) return false;
	if (!Stahl._loaded_StateTiering) {
		this.processEmotionNotetags1($dataStates);
		this.processStateBuffNotetags1($dataStates); //named StateBuffs to avoid confusion with base RPGMV buff

		this.processExtraEmotionNotetags1($dataStates);
		this.processExtraEmotionNotetags1($dataActors);
		this.processExtraEmotionNotetags1($dataEnemies);

		this.processBattlerEmotionNotetags1($dataActors);
		this.processBattlerEmotionNotetags1($dataEnemies);

		this.processEmotionNotetags2($dataStates);
		Stahl._loaded_StateTiering = true;
	}
	return true;
	};

	DataManager.processEmotionNotetags1 = function(group) {
		$dataEmotions = $dataEmotions || [];
		for (var n = 1; n < group.length; n++) {
			var obj = group[n];
			var notedata = obj.note.split(/[\r\n]+/);

			for (var i = 0; i < notedata.length; i++) {
				var line = notedata[i];

				if (line.match(/<EMOTION TYPE: (.*), (\d+)>/i)) {
					obj.isEmotion = true;
					obj.emotionName = obj.name;
					obj.emotionType = String(RegExp.$1).toUpperCase();
					obj.emotionTier = parseInt(RegExp.$2);
				}

				if (line.match(/<EMOTION STRONG: (.*)>/i)) {
					obj.emotionStrong = obj.emotionStrong || [];
					obj.emotionStrong.push(String(RegExp.$1).toUpperCase());
				}

				if (line.match(/<EMOTION WEAK: (.*)>/i)) {
					obj.emotionWeak = obj.emotionWeak || [];
					obj.emotionWeak.push(String(RegExp.$1).toUpperCase());
				}
				
				if (line.match(/<EMOTION STRONG ALL>/i)) {
					obj.emotionStrongAll = true;
				}

				if (line.match(/<EMOTION WEAK ALL>/i)) {
					obj.emotionWeakAll = true;
				}

				if (line.match(/<EMOTION EXCLUDE FROM RANDOM>/i)) {
					obj.emotionExcludeFromRandom = true;
				}

				if (line.match(/<EMOTION NO EFFECT TEXT: (.*)>/i)) {
					obj.emotionNoEffectText = String(RegExp.$1).toUpperCase();
				}

				if (line.match(/<EMOTION SUP(?:PLEMENTARY)? BUFF: (.*)>/i)) {
					obj.emotionSupBuff = obj.emotionSupBuff || [];
					obj.emotionSupBuff.push(String(RegExp.$1).toUpperCase());
				}

				if (line.match(/<EMOTION COM(?:PLEMENTARY)? BUFF: (.*)>/i)) {
					obj.emotionComBuff = obj.emotionComBuff || [];
					obj.emotionComBuff.push(String(RegExp.$1).toUpperCase());
				}
			}

			if (obj.isEmotion) {
				$dataEmotions.push(obj);
			}
		}
	};

	DataManager.processEmotionNotetags2 = function(group) {
		$dataEmotions = $dataEmotions || [];
		for (var n = 1; n < group.length; n++) {
			var obj = group[n];
			var notedata = obj.note.split(/[\r\n]+/);

			for (var i = 0; i < notedata.length; i++) {
				var line = notedata[i];

				//EMOTION COPY TRAIT: ID, TAG
				if (line.match(/<EMOTION COPY TRAIT: (\d+)(?:, (.+))?>/i)) {
					let stateId = parseInt(RegExp.$1);
					let state = $dataStates[stateId];

					obj.isEmotion 					= true;
					obj.emotionName 				= state.emotionName;
					obj.emotionType 				= state.emotionType;
					obj.emotionTier 				= state.emotionTier;
					obj.emotionStrong 				= state.emotionStrong;
					obj.emotionWeak 				= state.emotionWeak;
					obj.emotionStrongAll 			= state.emotionStrongAll;
					obj.emotionWeakAll 				= state.emotionWeakAll;
					obj.emotionExcludeFromRandom	= state.emotionExcludeFromRandom;
					obj.emotionNoEffectText 		= state.emotionNoEffectText;
					obj.emotionSupBuff 				= state.emotionSupBuff;
					obj.emotionComBuff 				= state.emotionComBuff;

					if (RegExp.$2) obj.emotionTag = String(RegExp.$2).toUpperCase();
				}
			}

			if (obj.emotionTag) {
				$dataEmotions.push(obj);
			}
		}
	};

	DataManager.processStateBuffNotetags1 = function(group) {
		$dataStateBuffs = $dataStateBuffs || [];
		for (var n = 1; n < group.length; n++) {
			var obj = group[n];
			var notedata = obj.note.split(/[\r\n]+/);

			for (var i = 0; i < notedata.length; i++) {
				var line = notedata[i];

				if (line.match(/<STATE ?BUFF TYPE: (.*), ([\+\-]\d+)>/i)) {
					obj.isStateBuff = true;
					obj.stateBuffType = String(RegExp.$1).toUpperCase();
					obj.stateBuffTier = parseInt(RegExp.$2);
				}

				if (line.match(/<STATE ?BUFF ALT NAME: (.*)>/i)) {
					obj.stateBuffAltName = obj.stateBuffAltName || [];
					obj.stateBuffAltName.push(String(RegExp.$1).toUpperCase());
				}
			}

			if (obj.isStateBuff) {
				$dataStateBuffs.push(obj);
			}
		}
	};

	// in States, Enemies, and Actors
	DataManager.processExtraEmotionNotetags1 = function(group) {
		for (var n = 1; n < group.length; n++) {
			var obj = group[n];
			var notedata = obj.note.split(/[\r\n]+/);

			obj.emotionImmune = [];

			for (var i = 0; i < notedata.length; i++) {
				var line = notedata[i];

				if (line.match(/<EMOTION IMMUNE: (.*)>/i)) {
					obj.emotionImmune.push(String(RegExp.$1).toUpperCase());
				}

				if (line.match(/<EMOTION IMMUNE ALL>/i)) {
					obj.emotionImmuneAll = true;
				}

				if (line.match(/<EMOTION SUSCEPT(?:IBILITY)?: ([\+\-]\d+)>/i)) {
					obj.emotionSuscept = parseInt(RegExp.$1);
				}
			}
		}
	};

	DataManager.processBattlerEmotionNotetags1 = function(group) {
		for (var n = 1; n < group.length; n++) {
			var obj = group[n];
			var notedata = obj.note.split(/[\r\n]+/);

			obj.emotionImmune = [];

			for (var i = 0; i < notedata.length; i++) {
				var line = notedata[i];

				if (line.match(/<EMOTION USE TAG: (.*)>/i)) {
					obj.emotionTagUse = String(RegExp.$1).toUpperCase();
				}
			}
		}
	};

	DataManager.isEmotion = function(item) {
		return item && $dataEmotions.contains(item);
	};

	DataManager.getEmotion = function(type, tier, tag) {
		var findFunc = state => state.emotionType === type && state.emotionTier === tier;
		if (tag) findFunc = state => state.emotionType === type && state.emotionTier === tier && state.emotionTag === tag;
		return $dataEmotions.find(findFunc) || null;
	}

	DataManager.isStateBuff = function(item) {
		return item && $dataStateBuffs.contains(item);
	};

	DataManager.getStateBuff = function(type, tier) {
		return $dataStateBuffs.find(state => state.stateBuffType === type && state.stateBuffTier === tier) || null;
	}

	DataManager.isEmotionFromType = function(type) {
		return $dataEmotions.some(state => state.emotionType === type);
	}

	DataManager.isStateBuffFromType = function(type) {
		return $dataStateBuffs.some(state => state.stateBuffType === type);
	}

	DataManager.getMainEmotionTypeList = function() {
		return ["HAPPY", "SAD", "ANGRY"];
	}

	DataManager.getEmotionTypeList = function() {
		let result = [];
		for (let state of $dataEmotions) {
			if (!result.includes(state.emotionType)) {
				result.push(state.emotionType);
			}
		}
		return result;
	}

	DataManager.getEmotionsWithType = function(type) {
		return $dataEmotions.filter(state => state.emotionType === type)
	}

	DataManager.getMainStateBuffTypeList = function() {
		return ["ATTACK", "DEFENSE", "SPEED"];
	}

	DataManager.getStateBuffTypeList = function() {
		let result = [];
		for (let state of $dataStateBuffs) {
			if (!result.includes(state.stateBuffType)) {
				result.push(state.stateBuffType);
			}
		}
		return result;
	}

	DataManager.getMainStateBuffName = function(input) {
		input = input.toUpperCase();
		for (let state of $dataStateBuffs) {
			for (let altName of state.stateBuffAltName) {
				if (altName === input) {
					return state.stateBuffType;
				}
			}
		}
		return input;
	}

	DataManager.getMainStateTypeName = function(input) {
		input = input.toUpperCase();
		const isStateBuff = DataManager.isStateBuffFromType(input);
		if (isStateBuff) return DataManager.getMainStateBuffName(input);
		return input;
	}

	DataManager.getStateBuffAdjective = function(tier) {
		for (let key in Stahl.Parsed.BuffAdjective) {
			const a = Stahl.Parsed.BuffAdjective[key];
			if (a.tierChange == tier) {
				return a.adjective;
			}
		}
	};
}

// ================================ BATTLE MANAGER ================================ //
{
	BattleManager.addTextSplit = function(text) {
		const maxTextLength = 382;
		let lastIndex = text.lastIndexOf(" ");
		if (SceneManager._scene._logWindow._backBitmap.measureTextWidth(text, true) < maxTextLength || lastIndex < 0) {
			SceneManager._scene._logWindow.push("addText", text, 16)
			//break;
		} else {
			let textBeginning = text.slice(0, lastIndex)
			let textEnding = text.slice(lastIndex + 1)
			if (SceneManager._scene._logWindow._backBitmap.measureTextWidth(textBeginning, true) > maxTextLength) {
				lastIndex = text.lastIndexOf(" ", lastIndex - 1);
				textBeginning = text.slice(0, lastIndex)
				textEnding = text.slice(lastIndex + 1)
            }
			SceneManager._scene._logWindow.push("addText", textBeginning, 16)
			SceneManager._scene._logWindow.push("addText", textEnding, 16)
		}
	}
}

// ================================ BASIC STATE GETTERS ================================ //
{
	// Get emotion, gets only first as there can only be single emotion concurrent
	Game_Battler.prototype.emotionState = function() {
		return this.states().find(state => state.isEmotion) || null;
	};

	// Get buff, specify type as multiple type can exist
	Game_Battler.prototype.stateBuff = function(type) {
		type = type.toUpperCase();
		return this.states().find(state => state.isStateBuff && state.stateBuffType === type) || null;
	};

	// Get list of buff that battler has
	Game_Battler.prototype.stateBuffList = function() {
		return this.states().filter(state => state.isStateBuff);
	};

	Game_Battler.prototype.emotionStateType = function() {
		const curEmo = this.emotionState();
		return curEmo ? curEmo.emotionType : "NEUTRAL";
	};

	Game_Battler.prototype.emotionStateTier = function(type) {
		const curEmo = this.emotionState();
		if (!curEmo) return 0; // Emotion check. If none or invalid then 0.
		if (type) { // Specified, only get tier of that emotion. If not then 0.
			type = type.toUpperCase()
			return curEmo.emotionType === type ? curEmo.emotionTier : 0;
		} else { // No type specified, assume any emotion tier.
			return curEmo.emotionTier;
		}
	};

	Game_Unit.prototype.emotionStateTier = function(type) {
		let sum = 0;
		this.members().forEach(function (member) {
			sum += member.emotionStateTier(type);
		})
		return sum;
	};

	Game_Unit.prototype.emotionStateTierAverage = function(type) {
		return this.emotionStateTier(type) / this.members().length;
	};

	Game_Battler.prototype.stateBuffTier = function(type) {
		const curState = this.stateBuff(type);
		return curState ? curState.stateBuffTier : 0;
	};

	// OLD: returns the "tier" of the state.
	Game_Battler.prototype.stateTypeTier = function(type) {
		const isEmotion = DataManager.isEmotionFromType(type);
		return isEmotion ? this.emotionStateTier(type) : this.stateBuffTier(type)
	};

	//returns the tier of emotion relative to type. Inclufing disadvantageous emotion as negative. 
	//Ex: Check for happy, but is angry. Being opposite on intention, output as if -1 happy tier.
	//If the input is "neutral", All higher emotions are lower negative tier.
	Game_Battler.prototype.emotionStateTierCombined = function(type) {
		type = type.toUpperCase();
		const curEmo = this.emotionState();
		if (!curEmo) return 0;
		if (type === curEmo.emotionType) {
			return curEmo.emotionTier;
		} else if (curEmo.emotionWeak.includes(type) || type === "NEUTRAL") {
			return -curEmo.emotionTier;
		}
		return 0;
	};

	Game_Battler.prototype.isEmotionStrongAgainst = function(type) {
		const curEmo = this.emotionState();
		return curEmo.emotionStrong && curEmo.emotionStrong.includes(type);
	};

	Game_Battler.prototype.isEmotionWeakAgainst = function(type) {
		const curEmo = this.emotionState();
		return curEmo.emotionWeak && curEmo.emotionWeak.includes(type);
	};
	
	Game_Battler.prototype.getEmotionSuscept = function() {
		const battlerData = this.isActor() ? this.actor() : this.enemy();
		var battlerAcc = battlerData.emotionSuscept || 0;
		var stateAcc = this.states().reduce((acc, state) => acc + (state.emotionSuscept || 0), 0);
		return battlerAcc + stateAcc;
	};
}

// ================================ BASE GAME OMORI FIXES FUNCTIONS ================================ //
{
	Game_Battler.prototype.isEmotionAddable = function(type) {
		type = type.toUpperCase();
		const emoStateList = DataManager.getEmotionsWithType(type);

		return emoStateList.some(state => this.isStateAddable(state.id))

		switch(type.toLowerCase()) {
			case "happy":
				if(this.isStateAffected(7)) {return this.isStateAddable(8);}
				else if(this.isStateAffected(6)) {return this.isStateAddable(7);}
				else {return this.isStateAddable(6)}
			case "sad":
				if(this.isStateAffected(11)) {return this.isStateAddable(12);}
				else if(this.isStateAffected(10)) {return this.isStateAddable(11);}
				else {return this.isStateAddable(10)}
			case "angry":
				if(this.isStateAffected(15)) {return this.isStateAddable(16);}
				else if(this.isStateAffected(14)) {return this.isStateAddable(15);}
				else {return this.isStateAddable(14)}
			case "afraid":
				return this.isStateAddable(18);
		}
	}

	Game_Battler.prototype.isEmotionAffected = function(type, noCustom = false) {
		let Space_Ex_Boyfriend_Angry = this.isStateAffected(119) || this.isStateAffected(120) || this.isStateAffected(121);
		let Sweetheart_Happy = this.isStateAffected(197) || this.isStateAffected(122) || this.isStateAffected(123);
		let Unbread_Twins_Sad = this.isStateAffected(124) || this.isStateAffected(125) || this.isStateAffected(126);
		if(!!noCustom) {
			Space_Ex_Boyfriend_Angry = false;
			Sweetheart_Happy = false;
			Unbread_Twins_Sad = false;
		}
		switch(type.toLowerCase()) {
			case "happy":
				return this.isStateAffected(6) || this.isStateAffected(7) || this.isStateAffected(8) || Sweetheart_Happy;
			case "sad":
				return this.isStateAffected(10) || this.isStateAffected(11) || this.isStateAffected(12) || Unbread_Twins_Sad;
			case "angry":
				return this.isStateAffected(14) || this.isStateAffected(15) || this.isStateAffected(16) || Space_Ex_Boyfriend_Angry;
			case "afraid":
				return this.isStateAffected(18);
		}
	}

	Game_Battler.prototype.isAnyEmotionAffected = function(noCustom = false) {
		return !!this.isEmotionAffected("happy", noCustom) || !!this.isEmotionAffected("angry", noCustom) || !!this.isEmotionAffected("sad", noCustom) || !!this.isEmotionAffected("afraid", noCustom)
	}
}

// ================================ HIGHEST/LOWEST BUFF TIERS ================================ //
{
	//returns the highest buff tier
	Game_Battler.prototype.highestStateBuff = function() {
		return this.stateBuffList().reduce((prev, current) => (prev.stateBuffTier > current.stateBuffTier) ? prev : current, null);
	};

	//returns the lowest buff tier
	Game_Battler.prototype.lowestStateBuff = function() {
		return this.stateBuffList().reduce((prev, current) => (prev.stateBuffTier < current.stateBuffTier) ? prev : current, null);
	};

	//======== OLD FUNCTIONS ========//
	Game_Battler.prototype.highestBuffType = function() {
		let state = this.highestStateBuff();
		return state ? state.stateBuffType : null;
	};

	Game_Battler.prototype.lowestBuffType = function() {
		let state = this.lowestStateBuff();
		return state ? state.stateBuffType : null;
	};

	Game_Battler.prototype.highestBuffTier = function() {
		let state = this.highestStateBuff();
		return state ? state.stateBuffTier : null;
	};

	Game_Battler.prototype.lowestBuffTier = function() {
		let state = this.lowestStateBuff();
		return state ? state.stateBuffTier : null;
	};

	//======== HIGHEST/LOWEST BUFF TIERS GAME UNITS ========//
	Game_Unit.prototype.highestStateBuff = function(type) {
		let comparer = (prev, current) => (prev.highestStateBuff().stateBuffTier > current.highestStateBuff().stateBuffTier) ? prev : current;
		if (type) {
			type = DataManager.getMainStateBuffName(type);
			comparer = (prev, current) => (prev.stateBuff(type).stateBuffTier > current.stateBuff(type).stateBuffTier) ? prev : current;
		}
		return this.members().reduce(comparer, null);
	};

	Game_Unit.prototype.highestBuffTier = function(type) {
		return this.highestStateBuff(type).stateBuffTier;
	};

	Game_Unit.prototype.lowestStateBuff = function(type) {
		let comparer = (prev, current) => (prev.lowestStateBuff().stateBuffTier < current.lowestStateBuff().stateBuffTier) ? prev : current;
		if (type) {
			type = DataManager.getMainStateBuffName(type);
			comparer = (prev, current) => (prev.stateBuff(type).stateBuffTier < current.stateBuff(type).stateBuffTier) ? prev : current;
		}
		return this.members().reduce(comparer, null);
	};

	Game_Unit.prototype.lowestBuffTier = function(type) {
		return this.lowestStateBuff(type).stateBuffTier;
	};

	Game_Battler.prototype.averageBuffTier = function() {
		let sum = 0
		let stateList = DataManager.getStateBuffTypeList()
		for (let i = 0; i < stateList.length; i++) {
			sum += this.stateTypeTier(stateList[i])
		}
		return sum / stateList.length;
	};

	// Returns ONLY buff tiers sum, good for clean buff check
	Game_Battler.prototype.totalBuffTier = function() {
		let sum = 0
		let stateList = DataManager.getStateBuffTypeList()
		for (let i = 0; i < stateList.length; i++) {
			sum += Math.max(0, this.stateTypeTier(stateList[i]))
		}
		return sum;
	};

	// Returns ONLY debuff tiers sum, good for clean debuff check
	Game_Battler.prototype.totalDebuffTier = function() {
		let sum = 0
		let stateList = DataManager.getStateBuffTypeList()
		for (let i = 0; i < stateList.length; i++) {
			sum += Math.min(0, this.stateTypeTier(stateList[i]))
		}
		return sum;
	};

    // Returns the average tier of every buff if used with no argument 
	Game_Unit.prototype.averageBuffTier = function(type) {
		let sum = 0
		let members = this.members()
		for (let i = 0; i < members.length; i++) {
			sum += type == undefined ? members[i].averageBuffTier() : members[i].stateTypeTier(type)
		}
		return sum / members.length;
	};

	// POLYMORPHISM !!!!
	Game_Unit.prototype.totalBuffTier = function() {
		let sum = 0;
		this.members().forEach(function (member) {
			sum += member.totalBuffTier();
		})
		return sum;
	};

	Game_Unit.prototype.totalDebuffTier = function() {
		let sum = 0;
		this.members().forEach(function (member) {
			sum += member.totalDebuffTier();
		})
		return sum;
	};

	Game_Unit.prototype.totalBuffTierAverage = function() {
		return this.totalBuffTier() / this.members().length;
	};

	Game_Unit.prototype.totalDebuffTierAverage = function() {
		return this.totalDebuffTier() / this.members().length;
	};

	// ================================ EMOTION UNITS ================================
	Game_Unit.prototype.emotionVariance = function() {
		let emoList = []
		this.members().forEach(function (member) {
			let item = member.emotionStateType();
			if (emoList.indexOf(item) === -1) {
				emoList.push(item);
			}
		})
		return emoList.length;
	};
}

// ================================ BASIC ADDING STATES ================================ //
{
	//For old plugin compatibility purposes, combining both buffs and emotions
	Game_Battler.prototype.addStateTier = function(type, tier = 1, parseText = false) {
		type = type.toUpperCase();
		type = DataManager.getMainStateBuffName(type); //if it's not state buff it will just ignore
		const isEmotion = DataManager.isEmotionFromType(type);
		//const isStateBuff = DataManager.isStateBuffFromType(type);

		if (isEmotion) {
			tier += this.getEmotionSuscept() * (tier > 0 ? 1 : -1);
			tier = Math.max(tier, 0)
			console.log("emotion add tier =", tier);
		}
		if (tier === 0) {
			console.log("addStateTier tier = 0");
			return;
		}

		const battlerData = this.isActor() ? this.actor() : this.enemy();

		const curState = isEmotion ? this.emotionState() : this.stateBuff(type);
		const curTier = isEmotion ? this.emotionStateTier(type) : this.stateBuffTier(type);
		var noChange = false;
		var customTag = battlerData.emotionTagUse || null;

		const getState = function(type, tier) {
			return isEmotion ? DataManager.getEmotion(type, tier, customTag) : DataManager.getStateBuff(type, tier);
		}

		const parseTextBoth = function(battler) {
			if (parseText) {
				if (isEmotion) {
					if (noChange) battler._noEffectMessage = true;
					battler.parseEmotionText(type);
				} else {
					if (noChange) battler._noStateMessage = true;
					battler.parseBuffText(type, tier);
				}
			}
		}

		if (curState && curTier + tier == 0) { // 0 tier result means no state
			this.removeState(curState.id);
			parseTextBoth(this);
			console.log("curTier + tier == 0 return");
			return;
		}

		let finalState = getState(type, curTier + tier);
		let resistCheck = tier;

		if (!finalState) console.log("initial finalState of tier", curTier + tier, "doesn't exist!");

		while (!finalState || this.isStateResist(finalState.id)) {
			resistCheck += resistCheck > 0 ? -1 : 1; //check "lesser" tiered state, nearer to 0
			if (resistCheck === 0) {
				noChange = true;
				console.log("noChange break");
				break;
			} else if (curState && curTier + resistCheck === 0) { // 0 tier result means no state
				this.removeState(curState.id);
				parseTextBoth(this);
				console.log("resistCheck return");
				return;
			}
			finalState = getState(type, curTier + resistCheck);
		}
			
		if (curState && !noChange) {
			this.removeState(curState.id);
		}

		//add new state
		if (finalState) {
			this._noStateMessage = undefined; //set to undefined before so it works with multiple additions
			this._bypassRemoveRestriction = true;
			this.addState(finalState.id);
		} else if (Stahl.Param.ReaddState && noChange) { //attempt add back in same when readd
			this.addState(curState.id);
		}

		console.log(this.name(), "got StateTier", type, tier, "| turns", curState ? curState.name : "NO STATE", "into", finalState ? finalState.name : "NO STATE", "but noChange", noChange);

		parseTextBoth(this);
	}

	Game_Battler.prototype.addEmotion = function(type, tier = 1, parseText = false) {
		this.addStateTier(type, tier, parseText);
	}

	Game_Battler.prototype.addStateBuff = function(type, tier = 1, parseText = false) {
		this.addStateTier(type, tier, parseText);
	}

	// TEXT PARSING
	//Does the text for emotion change on battle log, enter what to display manually
	Game_Battler.prototype.isEmotionImmune = function(type) {
		const battlerData = this.isActor() ? this.actor() : this.enemy();
		return battlerData.emotionImmuneAll //battler's innate immunity
		|| (battlerData.emotionImmune && battlerData.emotionImmune.includes(type))
		|| this.states().some(state => state.emotionImmuneAll //states that add immunity
		|| (state.emotionImmune && state.emotionImmune.includes(type)));
	}

	Game_Battler.prototype.parseEmotionText = function(type) {
		const tname = this.name();
		const curState = this.emotionState();
		let text = "";

		if (this.isEmotionImmune(type)) {
			text = `${tname} cannot be ${type}!`;
		} else if (this._noEffectMessage) {
			if (curState === null) { return }
			let em = curState.emotionNoEffectText;
			if (em)
				text = `${tname} can't get ${em}`;
			else
				text = `${tname} cannot be more ${curState.emotionName}!`;
		} else {
			text = tname + (this.isActor() ? curState.message1 : curState.message2);
		}

		BattleManager.addTextSplit(text);
	};

	//Does the text for buff change on battle log, enter what to display manually
	Game_Battler.prototype.parseBuffText = function(type, tier = 1) {
		if (tier == 0) return; //if tier 0 then it's nothing lol

		type = DataManager.getMainStateBuffName(type);
		const tname = this.name();
		const stat = type;

		let text = "";
		let adj = DataManager.getStateBuffAdjective(Math.abs(tier));

		if (!this._noStateMessage) {
			if (Stahl.Param.UseMaximumBuffText && Math.abs(tier) >= 6) {
				let hl = tier > 0 ? "maximized!" : "minimized!";
				text = `${tname}'s ${stat} was ${hl}`;
			} else {
				let hl = tier > 0 ? "rose" : "fell";
				if (adj.length > 0) {
					text = `${tname}'s ${stat} ${hl} ${adj}`;
				} else {
					text = `${tname}'s ${stat} ${hl}!`
				}
			}
		} else if (this._debuffImmune && tier < 0) {
			text = `${tname}'s ${stat} cannot be lowered!`;
		} else if (this._buffImmune && tier > 0) {
			text = `${tname}'s ${stat} cannot be raised!`;
		} else {
			let hl = tier > 0 ? "higher!" : "lower!";
			text = `${tname}'s ${stat} can't go any ${hl}`;
		}

		BattleManager.addTextSplit(text);
	};
}

// ================================ RANDOM ADDITION ================================ //
{
	//Adds random main emotion
	Game_Battler.prototype.addRandomMainEmotion = function(tier = 1, excludeCurrent = false, parseText = false) {
		let arr = DataManager.getMainEmotionTypeList();
		if (excludeCurrent) { //exclude current emotion
			const curEmo = this.emotionStateType();
			arr.filter(a => a !== curEmo);
		}
		let type = arr[Math.randomInt(arr.length)];
		this.addEmotion(type, tier, parseText);
	};

	//Adds random emotion
	Game_Battler.prototype.addRandomEmotion = function(tier = 1, excludeCurrent = false, parseText = false) {
		let arr = DataManager.getEmotionTypeList().filter(a => !a.emotionExcludeFromRandom);
		if (excludeCurrent) { //exclude current emotion
			const curEmo = this.emotionStateType();
			arr.filter(a => a !== curEmo);
		}
		let type = arr[Math.randomInt(arr.length)];
		this.addEmotion(type, tier, parseText);
	};

	//Adds random buffs
	Game_Battler.prototype.addRandomBuff = function(tier = 1, parseText = false) {
		let arr = DataManager.getStateBuffTypeList();
		let type = arr[Math.randomInt(arr.length)];
		this.addStateBuff(type, tier, parseText);
	};

	//Adds random tier of the type. Specifying min and max
	Game_Battler.prototype.addRandomTier = function(type, minTier = 1, maxTier = 1, parseText = false) {
		var tier = Math.floor(Math.random() * (maxTier - minTier + 1) + minTier);
		this.addStateTier(type, tier, parseText);
	};
}

// ================================ STATE BASED ADDITION ================================ //
{
	//Adds emotion on current emotion
	Game_Battler.prototype.addSupplementaryEmotion = function(tier = 1, parseText = false) {
		const curEmo = this.emotionState();
		if (curEmo) this.addEmotion(curEmo.emotionType, tier, parseText);
	};

	//Adds buff on current emotion's strength
	Game_Battler.prototype.addSupplementaryBuff = function(tier = 1, parseText = false) {
		const curEmo = this.emotionState();
		if (!curEmo) return;
		let arr = curEmo.emotionSupBuff;
		if (!arr || arr == []) return;
		let type = arr[Math.randomInt(arr.length)];
		this.addStateBuff(type, tier, parseText);
	};

	//Adds buff on current emotion's weakness
	Game_Battler.prototype.addComplimentaryBuff = function(tier = 1, parseText = false) {
		const curEmo = this.emotionState();
		if (!curEmo) return;
		let arr = curEmo.emotionComBuff;
		if (!arr || arr == []) return;
		let type = arr[Math.randomInt(arr.length)];
		this.addStateBuff(type, tier, parseText);
	};

	//Add emotion to the battler that is strong against the target. (Find target disadvantage. Target is sad then give happy, etc.)
	Game_Battler.prototype.addEmotionStrongAgainst = function(target, tier = 1, parseText = false) {
		const targetEmo = target.emotionState();
		if (!targetEmo) return;
		let arr = targetEmo.emotionWeak;
		if (!arr || arr == []) return;
		let type = arr[Math.randomInt(arr.length)];
		this.addEmotion(type, tier, parseText);
	};

	Game_Battler.prototype.addAdvantageEmotion = function(target, tier = 1, parseText = false) {
		this.addEmotionStrongAgainst(...arguments);
	};

	//Add emotion to the battler that is weak against the target. (Find target advantage. Target is sad then give angry, etc.)
	Game_Battler.prototype.addEmotionWeakAgainst = function(target, tier = 1, parseText = false) {
		const targetEmo = target.emotionState();
		if (!targetEmo) return;
		let arr = targetEmo.emotionStrong;
		if (!arr || arr == []) return;
		let type = arr[Math.randomInt(arr.length)];
		this.addEmotion(type, tier, parseText);
	};

	Game_Battler.prototype.addDisadvantageEmotion = function(target, tier = 1, parseText = false) {
		this.addEmotionWeakAgainst(...arguments);
	};

	//Adds buff type that is highest
	Game_Battler.prototype.addHighestBuff = function(tier = 1, parseText = false) {
		var type = this.highestBuffType();
		if (type) this.addStateBuff(type, tier, parseText);
	};

	//Adds buff type that is lowest
	Game_Battler.prototype.addLowestBuff = function(tier = 1, parseText = false) {
		var type = this.lowestBuffType();
		if (type) this.addStateBuff(type, tier, parseText);
	};
}

// ================================ TIER BASED CHANCE BOOLEAN ================================ //
{
	//Random chance based on state tier
	Game_Battler.prototype.chanceStateTier = function(type, baseRate, incrementRate) {
		let tier = this.stateTypeTier(type);
		let rate = baseRate + (tier * incrementRate);
		let roll = Math.random() < rate
		console.log("stateRate", rate, "type", type, "roll", roll);
		return roll;
	}

	//Random chance based on emotion tier, combining disadvantageous emotion as negative tier
	Game_Battler.prototype.chanceEmotionTier = function(type, baseRate, incrementRate) {
		let tier = this.emotionStateTierCombined(type);
		let rate = baseRate + (tier * incrementRate);
		let roll = Math.random() < rate
		console.log("emoRate", rate, "type", type, "roll", roll);
		return roll;
	}
}

// ================================ AI Targeting ================================ //
{
    Stahl.StateTiering.AIManager_setProperTarget = AIManager.setProperTarget;
    AIManager.setProperTarget = function(group) {
        this.setActionGroup(group);
        var line = this._aiTarget.toUpperCase();

        if (line.match(/HIGHESTTIER (.*)/i)) {
            var type = DataManager.getMainStateTypeName(String(RegExp.$1));
            return this.setHighestTierTarget(group, type);
        } else if (line.match(/LOWESTTIER (.*)/i)) {
            var type = DataManager.getMainStateTypeName(String(RegExp.$1));
            return this.setLowestTierTarget(group, type);
        } else if (line.match(/HIGHESTEMO (.*)/i)) {
            var type = DataManager.getMainStateTypeName(String(RegExp.$1));
            return this.setHighestEmotionTarget(group, type);
        } else if (line.match(/LOWESTEMO (.*)/i)) {
            var type = DataManager.getMainStateTypeName(String(RegExp.$1));
            return this.setLowestEmotionTarget(group, type);
        } else if (line.match(/EMOSTRONG/i)) {
            return this.setEmotionStrongAgainstTarget(group);
        } else if (line.match(/EMOWEAK/i)) {
            return this.setEmotionWeakAgainstTarget(group);
        };

        Stahl.StateTiering.AIManager_setProperTarget.call(this, group);
    }

	
	AIManager.setHighestTierTarget = function (group, type) {
		console.log("group: " + group)
        var maintarget = group[Math.randomInt(group.length)];
		for (var i = 0; i < group.length; ++i) {
			var target = group[i];
			if (target.stateTypeTier(type) > maintarget.stateTypeTier(type)) maintarget = target;
		}
        this.action().setTarget(maintarget.index())
		console.log("HIGHEST TIER TARGET:", type, "| got", maintarget.name());
	};

    AIManager.setLowestTierTarget = function(group, type) {
        var maintarget = group[Math.randomInt(group.length)];
		for (var i = 0; i < group.length; ++i) {
			var target = group[i];
			if (target.stateTypeTier(type) < maintarget.stateTypeTier(type)) maintarget = target;
		}
        this.action().setTarget(maintarget.index())
		console.log("LOWEST TIER TARGET:", type, "| got", maintarget.name());
    };

    AIManager.setHighestEmotionTarget = function(group, type) {
        var maintarget = group[Math.randomInt(group.length)];
		for (var i = 0; i < group.length; ++i) {
			var target = group[i];
			if (target.emotionStateTierCombined(type) > maintarget.emotionStateTierCombined(type)) maintarget = target;
		}
        this.action().setTarget(maintarget.index())
		console.log("HIGHEST EMOTION TARGET:", type, "| got", maintarget.name());
    };

    AIManager.setLowestEmotionTarget = function(group, type) {
        var maintarget = group[Math.randomInt(group.length)];
		for (var i = 0; i < group.length; ++i) {
			var target = group[i];
			if (target.emotionStateTierCombined(type) < maintarget.emotionStateTierCombined(type)) maintarget = target;
		}
        this.action().setTarget(maintarget.index())
		console.log("LOWEST EMOTION TARGET:", type, "| got", maintarget.name());
    };

    AIManager.setEmotionStrongAgainstTarget = function(group) {
		var subject = this.action().subject;
		var subjectEmo = subject.emotionState();
		if (subjectEmo) {
			group = group.filter(target => subjectEmo.emotionStrong.includes(target.emotionStateType()));
		}

		var maintarget = group[Math.randomInt(group.length)];
		this.action().setTarget(maintarget.index());
		console.log("EMOTION STRONG AGAINST TARGET: subject Emo", subjectEmo ? subjectEmo.name : "NO STATE", "| got", maintarget.name());
    };

	AIManager.setEmotionWeakAgainstTarget = function(group) {
		var subject = this.action().subject;
		var subjectEmo = subject.emotionState();
		if (subjectEmo) {
			group = group.filter(target => subjectEmo.emotionWeak.includes(target.emotionStateType()));
		}

		var maintarget = group[Math.randomInt(group.length)];
		this.action().setTarget(maintarget.index());
		console.log("EMOTION WEAK AGAINST TARGET: subject Emo", subjectEmo ? subjectEmo.name : "NO STATE", "| got", maintarget.name());
    };
}

// ================================ YEP ACTION SEQUENCE ================================ //
{
	Stahl.StateTiering.BattleManager_processActionSequence = BattleManager.processActionSequence;
	BattleManager.processActionSequence = function(actionName, actionArgs) {

		// ADD EMOTION TYPE TIER
		if (actionName.match(/ADD EMOTION (\w+) (\d+)/i)) {
			return this.actionAddEmotion(actionName, actionArgs);
		}

		// ADD STATE BUFF TYPE TIER
		if (actionName.match(/ADD STATE ?BUFF (\w+) (\d+)/i)) {
			return this.actionAddStateBuff(actionName, actionArgs);
		}

		return Stahl.StateTiering.BattleManager_processActionSequence.call(this, actionName, actionArgs);
	};

	BattleManager.actionAddEmotion = function(actionName, actionArgs) {
		var targets = this.makeActionTargets(actionArgs[0]);
		if (targets.length < 1) return false;

		var show = false;
		for (var i = 0; i < actionArgs.length; ++i) {
			var actionArg = actionArgs[i];
			if (actionArg.toUpperCase() === 'SHOW') show = true;
		}

		if (actionName.match(/ADD EMOTION (\w+) (\d+)/i)) {
			var type = RegExp.$1;
			var tier = Number(RegExp.$2);
		} else { return true; }
		
		targets.forEach(target => target.addEmotion(type, tier, show), this);
		
		return true;
	};

	BattleManager.actionAddStateBuff = function(actionName, actionArgs) {
		var targets = this.makeActionTargets(actionArgs[0]);
		if (targets.length < 1) return false;

		var show = false;
		for (var i = 0; i < actionArgs.length; ++i) {
			var actionArg = actionArgs[i];
			if (actionArg.toUpperCase() === 'SHOW') show = true;
		}

		if (actionName.match(/ADD STATE ?BUFF (\w+) (\d+)/i)) {
			var type = RegExp.$1;
			var tier = Number(RegExp.$2);
		} else { return true; }
		
		targets.forEach(target => target.addStateBuff(type, tier, show), this);
		
		return true;
	};
}

// ================================ DUAL ANIMATION SIDE, CARRY OVER FROM OLD PLUGIN ================================ //
{
	// No longer parameter ID because this is for Omori only anyways and causes bloat
	Game_Battler.prototype.hpHealAnim = function() {
		if (this.isActor()) this.startAnimation(212);
		else this.startAnimation(216);
	};
	
	Game_Battler.prototype.mpHealAnim = function() {
		if (this.isActor()) this.startAnimation(213);
		else this.startAnimation(217);
	};
	
	Game_Battler.prototype.buffAnim = function() {
		if (this.isActor()) this.startAnimation(214);
		else this.startAnimation(218);
	};
	
	Game_Battler.prototype.debuffAnim = function() {
		if (this.isActor()) this.startAnimation(215);
		else this.startAnimation(219);
	};
}